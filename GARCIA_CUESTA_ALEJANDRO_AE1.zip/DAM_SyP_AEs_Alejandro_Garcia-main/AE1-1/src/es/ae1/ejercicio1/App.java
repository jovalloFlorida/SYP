package es.ae1.ejercicio1;

public class App {

	public void SayHello2() {
		System.out.println("Hola Mundo 2");
	}
	
}
